import express from 'express';
import axios from 'axios';

const router = express.Router();

// AI clip analysis — called by frontend when user hits "Analyze with AI"
// This can also be called server-side for more powerful analysis
router.post('/analyze', async (req, res) => {
  const { youtubeUrl, videoTitle, durationSec, contentType, clipLength, maxClips } = req.body;

  try {
    const response = await axios.post('https://api.anthropic.com/v1/messages', {
      model: 'claude-sonnet-4-6',
      max_tokens: 1500,
      messages: [{
        role: 'user',
        content: `You are a social media content strategist. Analyze this video and suggest ${maxClips} clips:
- URL: ${youtubeUrl || 'uploaded file'}
- Title: ${videoTitle || 'unknown'}
- Duration: ${durationSec}s
- Content type: ${contentType}
- Clip length: ${clipLength}

Return ONLY a JSON array of clip objects with: id, title, startTime, endTime, reason, tags, engagementScore, platform`
      }]
    }, {
      headers: { 'x-api-key': process.env.ANTHROPIC_API_KEY, 'anthropic-version': '2023-06-01', 'Content-Type': 'application/json' }
    });

    const text = response.data.content.map(c => c.text || '').join('');
    const match = text.match(/\[[\s\S]*\]/);
    if (!match) throw new Error('No clips generated');
    res.json({ clips: JSON.parse(match[0]) });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
