import express from 'express';
import { google } from 'googleapis';
import axios from 'axios';

const router = express.Router();

// ── HELPERS ──────────────────────────────────────────────────────────────────

function googleOAuthClient() {
  return new google.auth.OAuth2(
    process.env.GOOGLE_CLIENT_ID,
    process.env.GOOGLE_CLIENT_SECRET,
    process.env.GOOGLE_REDIRECT_URI
  );
}

// ── YOUTUBE ──────────────────────────────────────────────────────────────────

// Step 1: redirect user to Google consent screen
router.get('/youtube', (req, res) => {
  const oauth2 = googleOAuthClient();
  const url = oauth2.generateAuthUrl({
    access_type: 'offline',
    prompt: 'consent',
    scope: [
      'https://www.googleapis.com/auth/youtube.upload',
      'https://www.googleapis.com/auth/youtube.readonly',
      'profile',
      'email'
    ]
  });
  res.redirect(url);
});

// Step 2: Google redirects back here with ?code=...
router.get('/youtube/callback', async (req, res) => {
  const { code } = req.query;
  if (!code) return res.redirect(`${process.env.FRONTEND_URL}?error=no_code`);
  try {
    const oauth2 = googleOAuthClient();
    const { tokens } = await oauth2.getToken(code);
    oauth2.setCredentials(tokens);

    // Fetch user profile to get display name + avatar
    const people = google.people({ version: 'v1', auth: oauth2 });
    const profile = await people.people.get({
      resourceName: 'people/me',
      personFields: 'names,photos'
    });
    const name   = profile.data.names?.[0]?.displayName || 'YouTube User';
    const avatar = profile.data.photos?.[0]?.url || '';

    req.session.youtube = { tokens, name, avatar };
    res.redirect(`${process.env.FRONTEND_URL}?connected=youtube`);
  } catch (err) {
    console.error('YouTube OAuth error:', err.message);
    res.redirect(`${process.env.FRONTEND_URL}?error=youtube_auth_failed`);
  }
});

// Disconnect
router.get('/youtube/disconnect', (req, res) => {
  delete req.session.youtube;
  res.json({ ok: true });
});

// ── TIKTOK ───────────────────────────────────────────────────────────────────

router.get('/tiktok', (req, res) => {
  const params = new URLSearchParams({
    client_key:     process.env.TIKTOK_CLIENT_KEY,
    scope:          'user.info.basic,video.upload',
    response_type:  'code',
    redirect_uri:   process.env.TIKTOK_REDIRECT_URI,
    state:          'clipforge'
  });
  res.redirect(`https://www.tiktok.com/v2/auth/authorize/?${params}`);
});

router.get('/tiktok/callback', async (req, res) => {
  const { code } = req.query;
  if (!code) return res.redirect(`${process.env.FRONTEND_URL}?error=no_code`);
  try {
    const tokenRes = await axios.post('https://open.tiktokapis.com/v2/oauth/token/', new URLSearchParams({
      client_key:    process.env.TIKTOK_CLIENT_KEY,
      client_secret: process.env.TIKTOK_CLIENT_SECRET,
      code,
      grant_type:    'authorization_code',
      redirect_uri:  process.env.TIKTOK_REDIRECT_URI
    }), { headers: { 'Content-Type': 'application/x-www-form-urlencoded' } });

    const { access_token, open_id } = tokenRes.data;

    // Fetch display name
    const userRes = await axios.get('https://open.tiktokapis.com/v2/user/info/', {
      headers: { Authorization: `Bearer ${access_token}` },
      params: { fields: 'display_name,avatar_url' }
    });
    const name = userRes.data.data?.user?.display_name || 'TikTok User';

    req.session.tiktok = { access_token, open_id, name };
    res.redirect(`${process.env.FRONTEND_URL}?connected=tiktok`);
  } catch (err) {
    console.error('TikTok OAuth error:', err.message);
    res.redirect(`${process.env.FRONTEND_URL}?error=tiktok_auth_failed`);
  }
});

router.get('/tiktok/disconnect', (req, res) => {
  delete req.session.tiktok;
  res.json({ ok: true });
});

// ── INSTAGRAM ────────────────────────────────────────────────────────────────

router.get('/instagram', (req, res) => {
  const params = new URLSearchParams({
    client_id:     process.env.INSTAGRAM_CLIENT_ID,
    redirect_uri:  process.env.INSTAGRAM_REDIRECT_URI,
    scope:         'user_profile,user_media',
    response_type: 'code'
  });
  res.redirect(`https://api.instagram.com/oauth/authorize?${params}`);
});

router.get('/instagram/callback', async (req, res) => {
  const { code } = req.query;
  if (!code) return res.redirect(`${process.env.FRONTEND_URL}?error=no_code`);
  try {
    const tokenRes = await axios.post('https://api.instagram.com/oauth/access_token', new URLSearchParams({
      client_id:     process.env.INSTAGRAM_CLIENT_ID,
      client_secret: process.env.INSTAGRAM_CLIENT_SECRET,
      grant_type:    'authorization_code',
      redirect_uri:  process.env.INSTAGRAM_REDIRECT_URI,
      code
    }), { headers: { 'Content-Type': 'application/x-www-form-urlencoded' } });

    const { access_token, user_id } = tokenRes.data;

    const userRes = await axios.get(`https://graph.instagram.com/${user_id}`, {
      params: { fields: 'id,username', access_token }
    });
    const name = userRes.data.username || 'Instagram User';

    req.session.instagram = { access_token, user_id, name };
    res.redirect(`${process.env.FRONTEND_URL}?connected=instagram`);
  } catch (err) {
    console.error('Instagram OAuth error:', err.message);
    res.redirect(`${process.env.FRONTEND_URL}?error=instagram_auth_failed`);
  }
});

router.get('/instagram/disconnect', (req, res) => {
  delete req.session.instagram;
  res.json({ ok: true });
});

export default router;
