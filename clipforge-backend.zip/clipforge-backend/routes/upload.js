import express from 'express';
import { google } from 'googleapis';
import axios from 'axios';
import fs from 'fs';
import { processClip, cleanupFile } from '../services/videoProcessor.js';

const router = express.Router();

// Auth guard
function requireAuth(platforms) {
  return (req, res, next) => {
    const missing = platforms.filter(p => !req.session[p]);
    if (missing.length > 0 && platforms.length > 0) {
      // Only block if ALL requested platforms are missing
      const requested = req.body.platforms || [];
      const missingRequested = requested.filter(p => !req.session[p]);
      if (missingRequested.length === requested.length) {
        return res.status(401).json({ error: 'No connected accounts for requested platforms' });
      }
    }
    next();
  };
}

// ── MAIN PUBLISH ENDPOINT ─────────────────────────────────────────────────────
router.post('/publish', async (req, res) => {
  const { youtubeUrl, clips, platforms, caption, subtitles = true, vertical = true } = req.body;

  if (!clips || clips.length === 0) return res.status(400).json({ error: 'No clips provided' });
  if (!platforms || platforms.length === 0) return res.status(400).json({ error: 'No platforms selected' });

  // Validate at least one platform is connected
  const connectedPlatforms = platforms.filter(p => req.session[p]);
  if (connectedPlatforms.length === 0) {
    return res.status(401).json({ error: 'Please connect at least one platform account before publishing' });
  }

  const results = [];
  let sourceFile = null; // cache downloaded video across clips

  try {
    for (const clip of clips) {
      console.log(`\n🎬 Processing clip: ${clip.title}`);

      // Process clip (download once, reuse for multiple clips)
      const clipPath = await processClip({
        youtubeUrl,
        startSec: clip.startTime,
        endSec: clip.endTime,
        subtitles,
        vertical,
        sourceFile
      });

      // Post to each connected platform
      for (const platform of connectedPlatforms) {
        try {
          let postResult = null;
          if (platform === 'youtube')   postResult = await postToYouTube(req.session.youtube, clipPath, clip, caption);
          if (platform === 'tiktok')    postResult = await postToTikTok(req.session.tiktok, clipPath, clip, caption);
          if (platform === 'instagram') postResult = await postToInstagram(req.session.instagram, clipPath, clip, caption);
          if (postResult) results.push({ platform, clipId: clip.id, ...postResult });
        } catch (err) {
          console.error(`⚠ Failed to post to ${platform}:`, err.message);
          results.push({ platform, clipId: clip.id, error: err.message });
        }
      }

      // Clean up processed clip file
      cleanupFile(clipPath);
    }

    // Clean up downloaded source
    if (sourceFile) cleanupFile(sourceFile);

    res.json({ ok: true, posts: results });
  } catch (err) {
    if (sourceFile) cleanupFile(sourceFile);
    console.error('Publish error:', err);
    res.status(500).json({ error: err.message });
  }
});

// ── YOUTUBE UPLOAD ────────────────────────────────────────────────────────────
async function postToYouTube(session, videoPath, clip, caption) {
  const oauth2 = new google.auth.OAuth2(
    process.env.GOOGLE_CLIENT_ID,
    process.env.GOOGLE_CLIENT_SECRET,
    process.env.GOOGLE_REDIRECT_URI
  );
  oauth2.setCredentials(session.tokens);

  // Auto-refresh token if expired
  if (session.tokens.expiry_date && session.tokens.expiry_date < Date.now()) {
    const { credentials } = await oauth2.refreshAccessToken();
    session.tokens = credentials;
  }

  const youtube = google.youtube({ version: 'v3', auth: oauth2 });

  const videoMetadata = {
    snippet: {
      title: clip.title.substring(0, 100),
      description: `${caption}\n\n#Shorts`,
      tags: ['shorts', 'clip', 'viral'],
      categoryId: '22', // People & Blogs
    },
    status: {
      privacyStatus: 'public',
      selfDeclaredMadeForKids: false,
    },
  };

  console.log('📤 Uploading to YouTube...');
  const response = await youtube.videos.insert({
    part: ['snippet', 'status'],
    requestBody: videoMetadata,
    media: {
      body: fs.createReadStream(videoPath),
    },
  });

  const videoId = response.data.id;
  console.log('✅ YouTube upload complete:', videoId);
  return { url: `https://youtube.com/shorts/${videoId}`, videoId };
}

// ── TIKTOK UPLOAD ─────────────────────────────────────────────────────────────
async function postToTikTok(session, videoPath, clip, caption) {
  const { access_token } = session;

  // Step 1: init upload
  const initRes = await axios.post('https://open.tiktokapis.com/v2/post/publish/video/init/', {
    post_info: {
      title: caption.substring(0, 150),
      privacy_level: 'PUBLIC_TO_EVERYONE',
      disable_duet: false,
      disable_comment: false,
      disable_stitch: false,
    },
    source_info: {
      source: 'FILE_UPLOAD',
      video_size: fs.statSync(videoPath).size,
      chunk_size: fs.statSync(videoPath).size,
      total_chunk_count: 1,
    }
  }, {
    headers: { Authorization: `Bearer ${access_token}`, 'Content-Type': 'application/json' }
  });

  const { upload_url, publish_id } = initRes.data.data;

  // Step 2: upload video bytes
  const videoBuffer = fs.readFileSync(videoPath);
  await axios.put(upload_url, videoBuffer, {
    headers: {
      'Content-Type': 'video/mp4',
      'Content-Range': `bytes 0-${videoBuffer.length - 1}/${videoBuffer.length}`,
    }
  });

  console.log('✅ TikTok upload complete:', publish_id);
  return { publish_id, url: 'https://tiktok.com' };
}

// ── INSTAGRAM UPLOAD ──────────────────────────────────────────────────────────
// Instagram requires a publicly accessible video URL, not a file upload.
// For production, upload the file to S3/Cloudflare R2 first, then pass the URL.
async function postToInstagram(session, videoPath, clip, caption) {
  const { access_token, user_id } = session;

  // NOTE: In production, replace this with a real public URL from your storage provider
  // e.g. upload to Cloudflare R2 and use the public URL
  console.warn('⚠ Instagram requires a public video URL. Upload to cloud storage first.');

  // Placeholder — swap `videoUrl` with your actual public URL after uploading to R2/S3
  const videoUrl = `https://your-storage.example.com/${clip.id}.mp4`;

  // Step 1: create media container
  const containerRes = await axios.post(
    `https://graph.instagram.com/${user_id}/media`,
    {
      media_type: 'REELS',
      video_url: videoUrl,
      caption: caption.substring(0, 2200),
      share_to_feed: true,
    },
    { params: { access_token } }
  );
  const creationId = containerRes.data.id;

  // Step 2: wait for processing
  await new Promise(r => setTimeout(r, 5000));

  // Step 3: publish
  const publishRes = await axios.post(
    `https://graph.instagram.com/${user_id}/media_publish`,
    { creation_id: creationId },
    { params: { access_token } }
  );

  console.log('✅ Instagram upload complete:', publishRes.data.id);
  return { mediaId: publishRes.data.id, url: 'https://instagram.com' };
}

export default router;
