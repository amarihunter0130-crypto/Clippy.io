# ClipForge Backend — Setup Guide

## What you need (all free)
- A **Railway** account → railway.app
- A **Google Cloud** account → console.cloud.google.com
- A **TikTok Developer** account → developers.tiktok.com
- **Node.js 18+** installed if running locally

---

## Step 1 — Deploy to Railway

1. Go to **github.com** and create a new repo called `clipforge-backend`
2. Upload all these backend files to it
3. Go to **railway.app** → New Project → Deploy from GitHub → pick your repo
4. Railway auto-detects Node.js and runs `npm start`
5. Click **Settings → Networking → Generate Domain**
6. Copy your Railway URL — looks like: `https://clipforge-backend-production.up.railway.app`

---

## Step 2 — YouTube / Google setup

1. Go to **console.cloud.google.com**
2. Click **Select Project → New Project** → name it `ClipForge`
3. Go to **APIs & Services → Library** → search `YouTube Data API v3` → Enable
4. Go to **APIs & Services → Credentials → + Create Credentials → OAuth 2.0 Client ID**
5. Application type: **Web application**
6. Name: `ClipForge`
7. Under **Authorized redirect URIs** add:
   ```
   https://YOUR-RAILWAY-URL/auth/youtube/callback
   ```
8. Click Create → copy **Client ID** and **Client Secret**

---

## Step 3 — TikTok setup

1. Go to **developers.tiktok.com** → sign in → **Manage Apps → Create App**
2. App name: `ClipForge` | Platform: **Web**
3. Under **Products** → add **Login Kit** and **Content Posting API**
4. Under **Login Kit → Redirect URI** add:
   ```
   https://YOUR-RAILWAY-URL/auth/tiktok/callback
   ```
5. Copy **Client Key** and **Client Secret**

---

## Step 4 — Set environment variables in Railway

In your Railway project → **Variables** tab → add each of these:

```
SESSION_SECRET        = any-long-random-string-you-make-up
FRONTEND_URL          = (leave blank or your github pages URL)
GOOGLE_CLIENT_ID      = from Step 2
GOOGLE_CLIENT_SECRET  = from Step 2
GOOGLE_REDIRECT_URI   = https://YOUR-RAILWAY-URL/auth/youtube/callback
TIKTOK_CLIENT_KEY     = from Step 3
TIKTOK_CLIENT_SECRET  = from Step 3
TIKTOK_REDIRECT_URI   = https://YOUR-RAILWAY-URL/auth/tiktok/callback
```

---

## Step 5 — Use it in ClipForge

1. Open ClipForge → go to Step 3 (Publish)
2. Paste your Railway URL into the **Backend URL** field
3. Click **Connect** — the dot turns green
4. Click **Sign in** next to YouTube or TikTok
5. A popup opens → log in with your account → popup closes → account shows as connected ✓

---

## Install system dependencies (Railway does this automatically)

```bash
# yt-dlp (video downloader)
pip install yt-dlp

# ffmpeg (video trimmer + subtitle burner)
# Railway Ubuntu: 
apt-get install ffmpeg

# whisper (AI subtitles) — optional
pip install openai-whisper
```

Railway's Nixpacks builder installs these automatically if you add a `nixpacks.toml`:

```toml
[phases.setup]
nixPkgs = ["ffmpeg", "yt-dlp", "python311Packages.openai-whisper"]
```
