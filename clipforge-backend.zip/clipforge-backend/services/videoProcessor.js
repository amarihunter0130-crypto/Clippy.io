import { exec, spawn } from 'child_process';
import { promisify } from 'util';
import path from 'path';
import fs from 'fs';
import { v4 as uuid } from 'uuid';

const execAsync = promisify(exec);
const TEMP_DIR  = './temp';
const YTDLP    = process.env.YTDLP_PATH  || 'yt-dlp';
const FFMPEG   = process.env.FFMPEG_PATH || 'ffmpeg';
const WHISPER  = process.env.WHISPER_PATH || 'whisper';

// ── DOWNLOAD ─────────────────────────────────────────────────────────────────

export async function downloadVideo(youtubeUrl) {
  const id  = uuid();
  const out = path.join(TEMP_DIR, `${id}.mp4`);
  const cmd = `${YTDLP} -f "bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best" --merge-output-format mp4 -o "${out}" "${youtubeUrl}"`;
  console.log('⬇  Downloading:', youtubeUrl);
  await execAsync(cmd, { timeout: 300_000 }); // 5 min max
  if (!fs.existsSync(out)) throw new Error('Download failed — output file not found');
  return out;
}

// ── TRIM ─────────────────────────────────────────────────────────────────────

export async function trimClip(inputPath, startSec, endSec) {
  const id  = uuid();
  const out = path.join(TEMP_DIR, `clip_${id}.mp4`);
  const dur = endSec - startSec;
  // -ss before -i = fast seek; re-encode for clean cut
  const cmd = `${FFMPEG} -y -ss ${startSec} -i "${inputPath}" -t ${dur} -c:v libx264 -preset fast -crf 23 -c:a aac -b:a 128k "${out}"`;
  console.log(`✂  Trimming ${startSec}s → ${endSec}s`);
  await execAsync(cmd, { timeout: 120_000 });
  return out;
}

// ── TRANSCRIBE (SUBTITLES) ────────────────────────────────────────────────────
// Uses OpenAI Whisper CLI. Install with: pip install openai-whisper
// Alternatively swap this for the Whisper API if you have an OpenAI key.

export async function transcribeClip(clipPath) {
  const dir  = path.dirname(clipPath);
  const base = path.basename(clipPath, '.mp4');
  const srtPath = path.join(dir, `${base}.srt`);

  console.log('🎙  Transcribing:', clipPath);
  try {
    await execAsync(
      `${WHISPER} "${clipPath}" --model small --output_format srt --output_dir "${dir}"`,
      { timeout: 180_000 }
    );
    if (!fs.existsSync(srtPath)) throw new Error('SRT not generated');
    return srtPath;
  } catch (err) {
    console.warn('⚠  Whisper not available, skipping subtitles:', err.message);
    return null; // subtitles are optional — don't fail the whole job
  }
}

// ── BURN SUBTITLES ────────────────────────────────────────────────────────────

export async function burnSubtitles(clipPath, srtPath) {
  if (!srtPath || !fs.existsSync(srtPath)) return clipPath; // no subs, return as-is

  const id  = uuid();
  const out = path.join(TEMP_DIR, `subbed_${id}.mp4`);

  // Style: white bold text with black outline, bottom-center
  const style = "FontName=Arial,FontSize=22,PrimaryColour=&H00FFFFFF,OutlineColour=&H00000000,Outline=2,Bold=1,Alignment=2";
  const escapedSrt = srtPath.replace(/\\/g, '/').replace(/:/g, '\\:');
  const cmd = `${FFMPEG} -y -i "${clipPath}" -vf "subtitles='${escapedSrt}':force_style='${style}'" -c:v libx264 -preset fast -crf 23 -c:a copy "${out}"`;

  console.log('💬  Burning subtitles');
  await execAsync(cmd, { timeout: 120_000 });
  return out;
}

// ── VERTICAL CROP (9:16 for Reels/TikTok/Shorts) ────────────────────────────

export async function cropVertical(clipPath) {
  const id  = uuid();
  const out = path.join(TEMP_DIR, `vertical_${id}.mp4`);
  // Smart crop: detect face/subject center, fallback to center crop
  const cmd = `${FFMPEG} -y -i "${clipPath}" -vf "crop=ih*9/16:ih:(iw-ih*9/16)/2:0,scale=1080:1920" -c:v libx264 -preset fast -crf 23 -c:a copy "${out}"`;
  console.log('📱  Converting to 9:16');
  await execAsync(cmd, { timeout: 120_000 });
  return out;
}

// ── FULL PIPELINE ─────────────────────────────────────────────────────────────
// Given a YouTube URL + clip spec, produce a final ready-to-upload video file.

export async function processClip({ youtubeUrl, startSec, endSec, subtitles = true, vertical = true, sourceFile = null }) {
  let sourcePath = sourceFile;

  // Download only if we don't already have the source
  if (!sourcePath || !fs.existsSync(sourcePath)) {
    sourcePath = await downloadVideo(youtubeUrl);
  }

  // Trim
  let clipPath = await trimClip(sourcePath, startSec, endSec);

  // Subtitles
  if (subtitles) {
    const srtPath  = await transcribeClip(clipPath);
    clipPath       = await burnSubtitles(clipPath, srtPath);
    if (srtPath && fs.existsSync(srtPath)) fs.unlinkSync(srtPath); // clean up
  }

  // Vertical crop for short-form platforms
  if (vertical) {
    const prevPath = clipPath;
    clipPath = await cropVertical(clipPath);
    if (fs.existsSync(prevPath) && prevPath !== clipPath) fs.unlinkSync(prevPath);
  }

  return clipPath;
}

// ── CLEANUP ───────────────────────────────────────────────────────────────────

export function cleanupFile(filePath) {
  try {
    if (filePath && fs.existsSync(filePath)) fs.unlinkSync(filePath);
  } catch {}
}

export function cleanupOldTempFiles(maxAgeMinutes = 60) {
  const now = Date.now();
  fs.readdirSync(TEMP_DIR).forEach(f => {
    const fp   = path.join(TEMP_DIR, f);
    const stat = fs.statSync(fp);
    if (now - stat.mtimeMs > maxAgeMinutes * 60 * 1000) {
      fs.unlinkSync(fp);
      console.log('🗑  Cleaned up:', f);
    }
  });
}

// Run temp cleanup every 30 min
setInterval(() => cleanupOldTempFiles(60), 30 * 60 * 1000);
