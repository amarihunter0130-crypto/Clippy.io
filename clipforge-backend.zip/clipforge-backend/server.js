import express from 'express';
import cors from 'cors';
import session from 'express-session';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';

import authRoutes from './routes/auth.js';
import clipRoutes from './routes/clips.js';
import uploadRoutes from './routes/upload.js';

dotenv.config();

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = process.env.PORT || 3000;

// Ensure temp dir exists
if (!fs.existsSync('./temp')) fs.mkdirSync('./temp');

app.use(cors({
  origin: process.env.FRONTEND_URL || '*',
  credentials: true
}));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(session({
  secret: process.env.SESSION_SECRET || 'clipforge-secret-change-me',
  resave: false,
  saveUninitialized: false,
  cookie: { secure: process.env.NODE_ENV === 'production', maxAge: 7 * 24 * 60 * 60 * 1000 }
}));

// Routes
app.use('/auth', authRoutes);
app.use('/clips', clipRoutes);
app.use('/upload', uploadRoutes);

// Health check
app.get('/health', (req, res) => res.json({ status: 'ok', version: '1.0.0' }));

// Connected accounts status
app.get('/accounts', (req, res) => {
  const accounts = {};
  if (req.session.youtube) accounts.youtube = { connected: true, name: req.session.youtube.name, avatar: req.session.youtube.avatar };
  if (req.session.tiktok)  accounts.tiktok  = { connected: true, name: req.session.tiktok.name };
  if (req.session.instagram) accounts.instagram = { connected: true, name: req.session.instagram.name };
  res.json(accounts);
});

app.listen(PORT, () => console.log(`✅ ClipForge backend running on port ${PORT}`));
